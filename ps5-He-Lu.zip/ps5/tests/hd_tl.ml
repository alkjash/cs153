let x = tl (4,7) in
let y = hd [8] in
x + y
