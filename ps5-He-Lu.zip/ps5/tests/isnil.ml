isnil [3;4]
