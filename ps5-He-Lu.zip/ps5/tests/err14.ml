if 3 then 3 else 4
