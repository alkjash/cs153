snd (fun x -> x)
