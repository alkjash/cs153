(fun x -> x + 3) true
