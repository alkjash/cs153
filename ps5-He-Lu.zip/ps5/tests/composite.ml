let f = (fun x y -> x + y) in
let g = f 7 in
g 9