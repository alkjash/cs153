if (5 < 3) then true else false
