5 < ((let y = 3 in fun z -> y) 15)
