snd (5,6)
