fst [3;4]
