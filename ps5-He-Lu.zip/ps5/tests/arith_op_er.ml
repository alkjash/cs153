let op = (fun x y -> x - y) in
(op 5) 6 + 3
