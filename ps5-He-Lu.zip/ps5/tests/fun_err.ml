let f = fun x -> x + 1 in
f false
