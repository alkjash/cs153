let g = (fun y -> y) in 
g = g
