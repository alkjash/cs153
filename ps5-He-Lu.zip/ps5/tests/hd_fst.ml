let tru = hd [5;6;7] = fst (5,7) in
hd [tru]
