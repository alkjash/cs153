if isnil [] then let x = 4 in x else let x = 3 in 7
